package vn.nsn.app.ocb.api.entity

class Body(
        val body: String
)