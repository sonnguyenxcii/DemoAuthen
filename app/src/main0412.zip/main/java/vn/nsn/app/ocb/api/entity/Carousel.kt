package vn.nsn.app.ocb.api.entity

class Carousel {
    var category: String? = ""
    var displayOrder: Int = 0
    var story: Story? = null
    var notification: Notification? = null
}