package vn.nsn.app.ocb.api.entity

class ChaptersList (
    val chapters: List<ChapterListItem>
)