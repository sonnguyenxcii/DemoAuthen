package vn.nsn.app.ocb.api.entity

class CodeInvite(val code: String?)