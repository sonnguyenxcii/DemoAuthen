package vn.nsn.app.ocb.api.entity

data class Genre(
        var title: String,
        var stories: ArrayList<Story>
)