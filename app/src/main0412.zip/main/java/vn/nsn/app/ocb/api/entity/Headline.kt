package vn.nsn.app.ocb.api.entity

class Headline (
        var carousel: ArrayList<Carousel>,
        var genres: ArrayList<Genre>
)