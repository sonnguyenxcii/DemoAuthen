package vn.nsn.app.ocb.api.entity

class LoginResponse(
        val user: User?,
        val meta: Meta?
)