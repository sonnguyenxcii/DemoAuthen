package vn.nsn.app.ocb.api.entity

class Meta(val isNewRegistration: Boolean)