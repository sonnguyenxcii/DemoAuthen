package vn.nsn.app.ocb.api.entity

class Notification(
        val id: Int,
        val title: String,
        val url: String?,
        val backgroundImageUrl: String
)