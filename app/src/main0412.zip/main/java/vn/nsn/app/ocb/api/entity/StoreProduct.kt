package vn.nsn.app.ocb.api.entity

data class StoreProduct(
        val name: String,
        val productId: String
)