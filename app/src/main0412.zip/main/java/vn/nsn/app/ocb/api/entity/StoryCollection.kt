package vn.nsn.app.ocb.api.entity

data class StoryCollection(
        val layout: String,
        val stories: List<Story>
)