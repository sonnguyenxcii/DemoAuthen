package vn.nsn.app.ocb.api.entity

class StoryProgress(
        var numberOpenedBalloons: HashMap<String, Int>,
        var sumBalloons: Int
)