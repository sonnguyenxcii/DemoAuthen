package vn.nsn.app.ocb.api.entity

class UserCode(val code: String)