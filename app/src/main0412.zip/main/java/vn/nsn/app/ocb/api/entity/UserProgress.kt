package vn.nsn.app.ocb.api.entity

class UserProgress(var progresses: HashMap<String, StoryProgress>)