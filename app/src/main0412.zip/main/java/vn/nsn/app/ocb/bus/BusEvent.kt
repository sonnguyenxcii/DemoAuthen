package vn.nsn.app.ocb.bus

class BusEvent(
        val eventType: Int,
        val data: Any?
)