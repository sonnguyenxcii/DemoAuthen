package vn.nsn.app.ocb.mvp

interface MvpPresenter