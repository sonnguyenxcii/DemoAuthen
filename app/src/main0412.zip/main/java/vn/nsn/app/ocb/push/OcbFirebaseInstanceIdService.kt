package vn.nsn.app.ocb.push

import com.google.firebase.iid.FirebaseInstanceIdService

class OcbFirebaseInstanceIdService : FirebaseInstanceIdService() {
}