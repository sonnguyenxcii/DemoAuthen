package vn.nsn.app.ocb.screen.authen.pincode

import vn.nsn.app.ocb.mvp.AndroidPresenter
import vn.nsn.app.ocb.mvp.AndroidView


interface CreatePinCodeContract : AndroidView {

}

interface CreatePinCodePresenterContract : AndroidPresenter<CreatePinCodeContract> {

}